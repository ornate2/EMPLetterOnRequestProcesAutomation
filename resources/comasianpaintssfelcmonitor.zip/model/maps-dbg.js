sap.ui.define([], function () {
    "use strict";

    return {
        getLabelByFieldNameForExcelDownload: function () {
            return Object.freeze({
                "empCode": "Emp Code",
                "title": "Title",
                "fullName": "Full Name",
                "eventReason": "Event Reason",
                "eventReasonDescription" : "Even Reason Description",
                "CommunicationStatus": "Communication Status",
                "CommunicationRemarks": "Communication Remarks",
                "IsEPUploaded": "EP Upload",
                "IsFileNetUploaded": "FileNet Upload",
                "effectiveDate": "Effective Date",
                "LetterTemplate": "Letter Template",
                "LetterTemplateDescription" : "Letter Template Description",
                "email": "Employee Email",
                "MailResponse": "Mail Response",
                "EPResponse": "EP Response",
                "FileNetResponse": "FileNet Response"
            });
        }       
    };
});