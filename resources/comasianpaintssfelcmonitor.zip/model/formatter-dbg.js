sap.ui.define([
    "./maps"
], function (maps) {
    "use strict";

    return {
        base64Encode(sValue) {
            return btoa(sValue);
        },
        // Begin of add by I589796 on 06/23/2023
        getEventReasonDescription: function (oValue) {

            var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();

            switch (oValue) {
                case "PRBCOM":
                    return oResourceBundle.getText("PRBCOM");
                case "PRBEXT":
                    return oResourceBundle.getText("PRBEXT");
                case "PROMO":
                    return oResourceBundle.getText("PROMO");
                case "PROMOWTRANS":
                    return oResourceBundle.getText("PROMOWTRANS");
                case "TRANBU":
                    return oResourceBundle.getText("TRANBU");
                case "TRANFUNC":
                    return oResourceBundle.getText("TRANFUNC");
                case "TRANICOT":
                    return oResourceBundle.getText("TRANICOT");
                case "TRANDEPT":
                    return oResourceBundle.getText("TRANDEPT");
                case "TRANDIV":
                    return oResourceBundle.getText("TRANDIV");
                case "TRANLOC":
                    return oResourceBundle.getText("TRANLOC");
                default:
                    return oValue;
            }

        },

        getLetterTemplateDescription: async function (oValue) {
            oValue = parseInt(oValue, 10);
            var that = this;
            var oModel = this.getView().getModel(),
                oOperation = oModel.bindContext("/getLetterTemplateDescriptions(...)");

            var oPromise = await oOperation.setParameter("LetterTemplate", oValue).execute();
            this.oOperation = oOperation;
            var oDisplay = oValue;
            var oDisplay = this.oOperation.getBoundContext().getObject().value;
            return oDisplay;

        }
        // End of add by I589796 on 06/23/2023
    };
}


);