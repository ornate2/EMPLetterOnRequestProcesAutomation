sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.sap.asianpaints.LetterOnRequestTaskUI.controller.App", {
        onInit() {
        }
      });
    }
  );
  